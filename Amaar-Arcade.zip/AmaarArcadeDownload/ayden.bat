@echo off
title Amaar's Battle Quest
color 0a

:: ============================
:: GAME VARIABLES
:: ============================
set playerhp=30
set enemyhp=25
set potion=2

cls
echo ================================
echo        AMAAR'S BATTLE QUEST
echo ================================
echo.
echo You wake up in a dark forest...
echo A wild enemy appears!
echo.
pause

:battle
cls
echo ================================
echo           BATTLE START
echo ================================
echo Your HP: %playerhp%
echo Enemy HP: %enemyhp%
echo Potions: %potion%
echo.
echo Choose your action:
echo 1) Attack
echo 2) Heavy Attack
echo 3) Drink Potion
echo 4) Run Away
echo.
set /p choice=Your move: 

if "%choice%"=="1" goto attack
if "%choice%"=="2" goto heavy
if "%choice%"=="3" goto potion
if "%choice%"=="4" goto run

goto battle

:attack
set /a dmg=%random% %%6 + 3
set /a enemyhp=%enemyhp%-%dmg%
echo.
echo You strike the enemy for %dmg% damage!
goto enemyturn

:heavy
set /a miss=%random% %%4
if %miss%==0 (
    echo.
    echo Your heavy attack MISSED!
    goto enemyturn
)
set /a dmg=%random% %%10 + 5
set /a enemyhp=%enemyhp%-%dmg%
echo.
echo You smash the enemy for %dmg% damage!
goto enemyturn

:potion
if %potion% LEQ 0 (
    echo.
    echo You have no potions left!
    pause
    goto battle
)
set /a playerhp=%playerhp%+10
set /a potion=%potion%-1
echo.
echo You drink a potion and heal +10 HP!
goto enemyturn

:run
echo.
echo You try to run away...
set /a escape=%random% %%3
if %escape%==0 (
    echo The enemy blocks your escape!
    pause
    goto enemyturn
)
echo You escaped safely!
pause
goto end

:enemyturn
if %enemyhp% LEQ 0 goto win

echo.
echo The enemy attacks!
set /a enemydmg=%random% %%8 + 2
set /a playerhp=%playerhp%-%enemydmg%
echo Enemy hits you for
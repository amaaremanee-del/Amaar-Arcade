@echo off
title Code Breaker
color 0E
setlocal enabledelayedexpansion

:menu
cls
echo ==========================
echo        CODE BREAKER
echo ==========================
echo.
echo 1) Play
echo 2) Instructions
echo 3) Quit
echo.
set /p choice=Choose: 

if "%choice%"=="1" goto play
if "%choice%"=="2" goto help
if "%choice%"=="3" exit
goto menu

:help
cls
echo CODE BREAKER
echo.
echo A secret 3-digit code (0-9) is generated.
echo You have 8 tries to guess it.
echo After each guess:
echo  - CORRECT: right number, right place
echo  - CLOSE: right number, wrong place
echo.
pause
goto menu

:play
set /a d1=%random% %% 10
set /a d2=%random% %% 10
set /a d3=%random% %% 10
set tries=8

:guess_loop
cls
echo ==========================
echo        CODE BREAKER
echo ==========================
echo Tries left: %tries%
echo.
set /p guess=Enter 3-digit code (e.g. 123): 

if not "%guess:~0,1%"=="" (
    set g1=%guess:~0,1%
    set g2=%guess:~1,1%
    set g3=%guess:~2,1%
) else (
    echo Invalid input.
    pause
    goto guess_loop
)

if "%g1%"=="%d1%" if "%g2%"=="%d2%" if "%g3%"=="%d3%" goto win

set correct=0
set close=0

if "%g1%"=="%d1%" set /a correct+=1
if "%g2%"=="%d2%" set /a correct+=1
if "%g3%"=="%d3%" set /a correct+=1

if "%g1%"=="%d2%" set /a close+=1
if "%g1%"=="%d3%" set /a close+=1
if "%g2%"=="%d1%" set /a close+=1
if "%g2%"=="%d3%" set /a close+=1
if "%g3%"=="%d1%" set /a close+=1
if "%g3%"=="%d2%" set /a close+=1

echo.
echo CORRECT: %correct%
echo CLOSE:   %close%
echo.
set /a tries-=1
if "%tries%"=="0" goto lose
pause
goto guess_loop

:win
cls
echo ==========================
echo        YOU CRACKED IT!
echo ==========================
echo.
echo The code was %d1%%d2%%d3%.
echo Nice work, hacker.
echo.
pause
goto menu

:lose
cls
echo ==========================
echo         GAME OVER
echo ==========================
echo.
echo You ran out of tries.
echo The code was %d1%%d2%%d3%.
echo.
pause
goto menu